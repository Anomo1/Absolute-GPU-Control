/**
 * ABSOLUTE GPU CONTROL - INJECTION SCRIPT
 * Version: 4.0 Pro
 * 
 * Execution Context: MAIN World
 * Timing: document_start (Runs before the website's own scripts)
 * 
 * Logic:
 * This script intercepts calls to create WebGL contexts on both standard
 * HTML Canvases and Offscreen Canvases. It effectively lies to the
 * website, telling it that the browser does not support 3D graphics.
 */

(function() {
  'use strict';

  // =============================================================================
  // 1. VISUAL CONFIRMATION (Console)
  // =============================================================================
  const LOG_STYLE = `
    background: #ff0000; 
    color: white; 
    font-weight: bold; 
    padding: 4px 8px; 
    border-radius: 4px; 
    font-size: 12px;
  `;
  
  console.log('%c⛔ GPU ACCELERATION BLOCKED', LOG_STYLE, 'The "Absolute GPU Control" extension has disabled WebGL for this tab.');

  // =============================================================================
  // 2. BLOCK HTML CANVAS (The Standard Way)
  // =============================================================================
  
  // Store the original function so we can still allow 2D graphics
  const originalGetContext = HTMLCanvasElement.prototype.getContext;

  // Overwrite the function
  HTMLCanvasElement.prototype.getContext = function(type, attributes) {
    // List of context types to kill
    const blockedContexts = [
      'webgl', 
      'webgl2', 
      'experimental-webgl',
      'moz-webgl', 
      'webkit-3d'
    ];

    if (blockedContexts.includes(type)) {
      // Optional: Log warnings only once per page load to avoid spamming console
      if (!window._gpuBlockedWarned) {
        console.warn("⚠️ Website attempted to initialize WebGL but was blocked.");
        window._gpuBlockedWarned = true;
      }
      return null; // The magic 'null' tells the site it's not supported
    }

    // If it's just '2d' or 'bitmaprenderer', let it pass through!
    return originalGetContext.apply(this, arguments);
  };

  // =============================================================================
  // 3. BLOCK OFFSCREEN CANVAS (The Modern/Background Way)
  // =============================================================================
  
  if (typeof OffscreenCanvas !== 'undefined') {
    const originalOffscreenGetContext = OffscreenCanvas.prototype.getContext;

    OffscreenCanvas.prototype.getContext = function(type, attributes) {
      const blockedContexts = ['webgl', 'webgl2', 'experimental-webgl'];

      if (blockedContexts.includes(type)) {
        return null;
      }

      return originalOffscreenGetContext.apply(this, arguments);
    };
  }

  // =============================================================================
  // 4. NUKE GLOBAL CONSTRUCTORS (The Feature Detection Way)
  // =============================================================================
  
  // Many advanced 3D libraries check if 'window.WebGLRenderingContext' exists
  // before even trying to create a canvas. We delete these references so
  // the libraries detect "Not Supported" immediately and switch to CPU mode.
  
  try {
    delete window.WebGLRenderingContext;
    delete window.WebGL2RenderingContext;
    
    // Safety: Define them as undefined just in case delete failed
    Object.defineProperty(window, 'WebGLRenderingContext', { value: undefined });
    Object.defineProperty(window, 'WebGL2RenderingContext', { value: undefined });
  } catch (e) {
    // Some browsers might protect these properties, but we try anyway.
    console.debug("Could not fully delete WebGL constructors, relying on context blocking.");
  }

})();