/**
 * ABSOLUTE GPU CONTROL - POPUP LOGIC
 * Version: 4.0 Pro
 */

const STORAGE_KEY = "blockedDomains";

// =============================================================================
// 1. INITIALIZATION & SETUP
// =============================================================================

document.addEventListener("DOMContentLoaded", async () => {
  // 1. Detect if the System/Browser GPU is actually active
  detectSystemStatus();

  // 2. Get the current active tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  if (!tab) return;

  // 3. Extract the clean hostname (e.g., "google.com")
  let currentHostname = "system";
  try {
    if (tab.url && !tab.url.startsWith("chrome:") && !tab.url.startsWith("edge:") && !tab.url.startsWith("opera:")) {
      currentHostname = new URL(tab.url).hostname;
    }
  } catch (e) {
    currentHostname = "system";
  }

  // 4. Update the UI text
  const domainLabel = document.getElementById("current-domain");
  domainLabel.textContent = currentHostname === "system" ? "Restricted System Page" : currentHostname;

  // 5. Initialize the interface
  loadUI(currentHostname, tab.id);
  setupListeners(currentHostname, tab.id);
});

// =============================================================================
// 2. SYSTEM DETECTION (Hardware Check)
// =============================================================================

function detectSystemStatus() {
  const badge = document.getElementById("system-badge");
  
  // Create a temporary canvas to check WebGL status
  const canvas = document.createElement('canvas');
  const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
  
  if (!gl) {
    badge.textContent = "SYSTEM: OFF";
    badge.className = "system-badge badge-off";
    return;
  }

  // Check for Software Rendering (SwiftShader/Basic Render)
  const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
  const renderer = debugInfo ? gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) : "";

  if (renderer.includes("SwiftShader") || renderer.includes("Software") || renderer.includes("Basic Render")) {
    badge.textContent = "SYSTEM: SOFTWARE"; // Technically ON, but slow
    badge.className = "system-badge badge-off";
  } else {
    badge.textContent = "SYSTEM: GPU ON";
    badge.className = "system-badge badge-on";
  }
}

// =============================================================================
// 3. UI RENDERING (The Visuals)
// =============================================================================

async function loadUI(hostname, tabId) {
  // Fetch rules from storage
  const data = await chrome.storage.local.get(STORAGE_KEY);
  const blockedDomains = data[STORAGE_KEY] || [];
  
  const isBlocked = blockedDomains.includes(hostname);
  const isSystem = hostname === "system";

  const statusText = document.getElementById("status-text");
  const toggleBtn = document.getElementById("toggle-btn");

  // Reset button state
  toggleBtn.disabled = false;
  toggleBtn.style.cursor = "pointer";
  toggleBtn.style.opacity = "1";

  if (isSystem) {
    statusText.textContent = "Extension Inactive";
    statusText.style.color = "#888";
    toggleBtn.textContent = "System Page";
    toggleBtn.className = "btn-disable"; 
    toggleBtn.style.opacity = "0.5";
    toggleBtn.disabled = true;
    toggleBtn.style.cursor = "not-allowed";
  } 
  else if (isBlocked) {
    // BLOCKED -> Show Enable
    statusText.textContent = "STATUS: BLOCKED (No GPU)";
    statusText.style.color = "var(--accent-red)";
    toggleBtn.textContent = "ENABLE ACCELERATION"; 
    toggleBtn.className = "btn-enable";
  } 
  else {
    // ALLOWED -> Show Disable
    statusText.textContent = "STATUS: ACTIVE (GPU Allowed)";
    statusText.style.color = "var(--accent-green)";
    toggleBtn.textContent = "DISABLE ACCELERATION";
    toggleBtn.className = "btn-disable";
  }

  // Render the list of blocked sites at the bottom
  renderList(blockedDomains, hostname, tabId);
}

// =============================================================================
// 4. EVENT LISTENERS (Clicks & Inputs)
// =============================================================================

function setupListeners(hostname, tabId) {
  
  // --- Main Toggle Button ---
  document.getElementById("toggle-btn").addEventListener("click", async () => {
    const data = await chrome.storage.local.get(STORAGE_KEY);
    const blockedDomains = data[STORAGE_KEY] || [];
    
    let newDomains;
    if (blockedDomains.includes(hostname)) {
      // Enable (Remove from block list)
      newDomains = blockedDomains.filter(d => d !== hostname);
    } else {
      // Disable (Add to block list)
      newDomains = [...blockedDomains, hostname];
    }

    await saveAndReload(newDomains, tabId);
    loadUI(hostname, tabId);
  });

  // --- Add Domain Button ---
  document.getElementById("add-btn").addEventListener("click", async () => {
    const input = document.getElementById("domain-input");
    const rawValue = input.value.trim();
    if (!rawValue) return;

    // Clean up the URL (remove https://, path, etc)
    const cleanDomain = rawValue
      .replace(/^https?:\/\//, '')
      .replace(/\/$/, '')
      .split('/')[0]
      .toLowerCase();

    const data = await chrome.storage.local.get(STORAGE_KEY);
    const blockedDomains = data[STORAGE_KEY] || [];

    if (!blockedDomains.includes(cleanDomain)) {
      const newDomains = [...blockedDomains, cleanDomain];
      
      // If we just added the site we are currently on, reload it
      const shouldReload = (hostname === cleanDomain);
      
      await saveAndReload(newDomains, shouldReload ? tabId : null);
      
      input.value = ""; // Clear input
      loadUI(hostname, tabId);
    }
  });
}

// =============================================================================
// 5. HELPER FUNCTIONS
// =============================================================================

async function saveAndReload(newDomains, tabIdToReload) {
  // 1. Save to Storage
  await chrome.storage.local.set({ [STORAGE_KEY]: newDomains });
  
  // 2. Notify Background Script to update injection rules
  try {
    await chrome.runtime.sendMessage({ action: "updateRules" });
  } catch (e) { 
    // Ignore error if background is sleeping
  }

  // 3. Reload the tab to apply changes (GPU context only resets on reload)
  if (tabIdToReload) {
    chrome.tabs.reload(tabIdToReload);
  }
}

function renderList(domains, currentHostname, currentTabId) {
  const list = document.getElementById("rules-list");
  const countBadge = document.getElementById("count-badge");
  
  list.innerHTML = "";
  countBadge.textContent = domains.length;

  domains.forEach(domain => {
    const li = document.createElement("li");
    
    const domainSpan = document.createElement("span");
    domainSpan.textContent = domain;
    
    const removeBtn = document.createElement("span");
    removeBtn.textContent = "REMOVE";
    removeBtn.className = "remove-btn";
    
    // Wire up the Remove Button inside the list
    removeBtn.addEventListener("click", async () => {
      const data = await chrome.storage.local.get(STORAGE_KEY);
      const currentList = data[STORAGE_KEY] || [];
      const newList = currentList.filter(d => d !== domain);
      
      // If user removed the site they are looking at, reload to re-enable GPU
      const shouldReload = (domain === currentHostname);

      await saveAndReload(newList, shouldReload ? currentTabId : null);
      
      // Update the UI
      loadUI(currentHostname, currentTabId);
    });

    li.appendChild(domainSpan);
    li.appendChild(removeBtn);
    list.appendChild(li);
  });
}