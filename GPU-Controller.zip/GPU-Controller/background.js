/**
 * ABSOLUTE GPU CONTROL - BACKGROUND WORKER
 * Version: 4.0 Pro
 * 
 * Responsibilities:
 * 1. Managing the "Nuclear" injection scripts.
 * 2. Handling Context Menu interactions.
 * 3. Updating the Icon Badge (Visual Feedback).
 */

const SCRIPT_ID = "gpu-blocker";
const STORAGE_KEY = "blockedDomains";

// =============================================================================
// 1. INITIALIZATION & EVENTS
// =============================================================================

// Run when extension is installed or browser is opened
chrome.runtime.onInstalled.addListener(() => {
  setupContextMenu();
  updateInjectionRules();
});

chrome.runtime.onStartup.addListener(() => {
  updateInjectionRules();
});

// Listen for storage changes (Syncs automatically when Popup changes data)
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes[STORAGE_KEY]) {
    updateInjectionRules();
    // Refresh the badge for the currently active tab
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) updateBadge(tabs[0].id, tabs[0].url);
    });
  }
});

// Update Badge when switching tabs
chrome.tabs.onActivated.addListener(activeInfo => {
  chrome.tabs.get(activeInfo.tabId, (tab) => {
    if (tab) updateBadge(tab.id, tab.url);
  });
});

// Update Badge when a tab finishes loading
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    updateBadge(tabId, tab.url);
  }
});

// =============================================================================
// 2. CORE LOGIC: SCRIPT INJECTION ("The Nuclear Option")
// =============================================================================

async function updateInjectionRules() {
  try {
    // 1. Always clean up old scripts first to prevent ID conflicts
    try {
      await chrome.scripting.unregisterContentScripts({ ids: [SCRIPT_ID] });
    } catch (e) {
      // Script didn't exist, which is fine
    }

    // 2. Get the list of blocked domains
    const data = await chrome.storage.local.get(STORAGE_KEY);
    const blockedDomains = data[STORAGE_KEY] || [];

    if (blockedDomains.length === 0) {
      console.log("✅ No domains blocked. GPU allowed everywhere.");
      return;
    }

    // 3. Generate match patterns
    // Matches: "http://example.com/*", "https://example.com/*", "https://sub.example.com/*"
    const matches = [];
    blockedDomains.forEach(domain => {
      matches.push(`*://${domain}/*`);
      matches.push(`*://*.${domain}/*`);
    });

    // 4. Register the killer script
    // "world: MAIN" is crucial. It lets us overwrite the page's actual JS variables.
    await chrome.scripting.registerContentScripts([{
      id: SCRIPT_ID,
      matches: matches,
      js: ["inject.js"],
      runAt: "document_start",
      world: "MAIN",
      allFrames: true 
    }]);

    console.log(`⛔ GPU Block Rules Updated. Blocking ${blockedDomains.length} domains.`);

  } catch (error) {
    console.error("❌ Failed to update injection rules:", error);
  }
}

// =============================================================================
// 3. UI FEEDBACK: ICON BADGE
// =============================================================================

async function updateBadge(tabId, urlString) {
  try {
    if (!urlString || urlString.startsWith("chrome://") || urlString.startsWith("edge://") || urlString.startsWith("opera://")) {
      chrome.action.setBadgeText({ tabId, text: "" });
      return;
    }

    const url = new URL(urlString);
    const hostname = url.hostname;
    
    const data = await chrome.storage.local.get(STORAGE_KEY);
    const blockedDomains = data[STORAGE_KEY] || [];

    // Check if current host is in the blocked list
    if (blockedDomains.includes(hostname)) {
      chrome.action.setBadgeText({ tabId, text: "OFF" });
      chrome.action.setBadgeBackgroundColor({ tabId, color: "#FF0000" }); // Red
    } else {
      chrome.action.setBadgeText({ tabId, text: "" }); // Clear badge
    }
  } catch (e) {
    // Fails on system pages, ignore
    chrome.action.setBadgeText({ tabId, text: "" });
  }
}

// =============================================================================
// 4. CONTEXT MENU (Right-Click Features)
// =============================================================================

function setupContextMenu() {
  chrome.contextMenus.create({
    id: "toggle-gpu",
    title: "Toggle GPU Acceleration for this site",
    contexts: ["page", "selection", "image", "link"]
  }, () => {
    if (chrome.runtime.lastError) {
      // Menu might already exist, ignore error
    }
  });
}

// Handle Context Menu Click
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "toggle-gpu") {
    const url = new URL(tab.url);
    const hostname = url.hostname;
    
    const data = await chrome.storage.local.get(STORAGE_KEY);
    const blockedDomains = data[STORAGE_KEY] || [];
    
    let newDomains;
    if (blockedDomains.includes(hostname)) {
      // Remove (Enable)
      newDomains = blockedDomains.filter(d => d !== hostname);
    } else {
      // Add (Disable)
      newDomains = [...blockedDomains, hostname];
    }
    
    await chrome.storage.local.set({ [STORAGE_KEY]: newDomains });
    
    // Reload tab to apply changes
    chrome.tabs.reload(tab.id);
  }
});